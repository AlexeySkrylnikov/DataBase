-- выбрать объявления всех пользователей и их возраст
SELECT
	GROUP_CONCAT(`id`) as announcements,
	`users_id` as users_id,
	(SELECT concat(`first_name`,' ',`last_name`) FROM `profiles` where `profiles`.`users_id` = `announcement`.`users_id`) as `users_name`,
    (SELECT timestampdiff(YEAR, `birthday`, NOW()) FROM `profiles` where `profiles`.`users_id` = `announcement`.`users_id`) as `users_age`
FROM
	`announcement`
GROUP BY
	`users_id`
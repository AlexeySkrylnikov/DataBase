	SELECT 
		count(`a`.`id`) as `announce_count`,
        concat(`p`.`first_name`,' ',`last_name`) as `user_name`,
        `c`.`name`
    FROM
		`announcement` `a`
	JOIN
		`cities` `c`
	ON 
		`c`.`id` = `a`.`cities_id`
	JOIN
		profiles `p`
	ON
		`p`.`users_id` = `a`.`users_id`
	GROUP BY
		`user_name`

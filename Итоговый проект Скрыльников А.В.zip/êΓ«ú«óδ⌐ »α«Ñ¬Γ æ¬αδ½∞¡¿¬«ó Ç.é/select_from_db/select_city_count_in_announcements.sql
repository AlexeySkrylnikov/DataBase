	SELECT 
		count(`a`.`cities_id`) as `cnt_city`,
        `c`.`name` as `city`,
        group_concat(concat(`p`.`first_name`, ' ', `p`.`last_name`)) as `users`
    FROM
		`announcement` `a`
	JOIN
		`cities` `c`
	ON 
		`c`.`id`= `a`.`cities_id`
	JOIN
		profiles `p`
	ON
		`p`.`users_id` = `a`.`users_id`
	GROUP BY
        `city`
	ORDER by
		`cnt_city` DESC
		
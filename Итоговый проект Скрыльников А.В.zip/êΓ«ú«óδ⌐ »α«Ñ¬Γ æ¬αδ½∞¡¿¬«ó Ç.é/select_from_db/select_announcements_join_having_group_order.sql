-- выбрать активные объявления и города этих объявлений, у которых цена больше 10000 
-- затем сгруппировать по разделам

SELECT
	group_concat(`a`.`id`) as `announce_id`,
    group_concat(`a`.`price`) as `price`,
    `s`.`name` as `section`,
    group_concat(`c`.`name`) as `city`,
    `anstat`.`name` as `status`
FROM 
	`announcement` `a`
JOIN 
	`sections` `s`
ON 
	`s`.`id` = `a`.`sections_id`
JOIN 
	`cities` `c`
ON 
	`c`.`id` = `a`.`cities_id`
JOIN
	`announces_status` `anstat`
ON
	`anstat`.`id` = `a`.`announces_status_id`
WHERE 
	`a`.`price` > 10000
GROUP BY 
	`s`.`id`
HAVING 
	`status` = 'Активно'
ORDER BY 
	`s`.`name`
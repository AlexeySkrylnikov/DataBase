-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: avito
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announce_photos`
--

DROP TABLE IF EXISTS `announce_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announce_photos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int unsigned NOT NULL,
  `media_id` int unsigned NOT NULL,
  `created_at` varchar(45) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NOW()',
  `updated_at` varchar(45) COLLATE utf8mb4_general_ci DEFAULT 'ON UPDATED CURRENT_TIMESTAMP()',
  PRIMARY KEY (`id`),
  KEY `fk_announce_photos_announcement1_idx` (`announcement_id`),
  KEY `fk_announce_photos_media1_idx` (`media_id`),
  CONSTRAINT `fk_announce_photos_announcement1` FOREIGN KEY (`announcement_id`) REFERENCES `announcement` (`id`),
  CONSTRAINT `fk_announce_photos_media1` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announce_photos`
--

LOCK TABLES `announce_photos` WRITE;
/*!40000 ALTER TABLE `announce_photos` DISABLE KEYS */;
INSERT INTO `announce_photos` VALUES (37,1,15,'2021-03-14 14:51:52',NULL),(38,2,3,'2021-03-14 14:51:52',NULL),(39,14,11,'2021-03-14 14:51:52',NULL),(40,4,6,'2021-03-14 14:51:52',NULL),(41,3,5,'2021-03-14 14:51:52',NULL),(42,8,7,'2021-03-14 14:51:52',NULL),(43,7,8,'2021-03-14 14:51:52',NULL),(44,15,13,'2021-03-14 14:51:52',NULL),(45,12,20,'2021-03-14 14:51:52',NULL),(46,5,10,'2021-03-14 14:51:52',NULL),(47,5,9,'2021-03-14 14:51:52',NULL),(48,7,2,'2021-03-14 14:51:52',NULL);
/*!40000 ALTER TABLE `announce_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announce_with_services`
--

DROP TABLE IF EXISTS `announce_with_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announce_with_services` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `start_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'дата начала действия услуги для объявления',
  `stop_date` datetime DEFAULT NULL COMMENT 'дата окончания действия услуги для объявления',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `announcement_id` int unsigned NOT NULL,
  `services_and_prices_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_announce_with_services_announcement1_idx` (`announcement_id`),
  KEY `fk_announce_with_services_services_and_prices1_idx` (`services_and_prices_id`),
  CONSTRAINT `fk_announce_with_services_announcement1` FOREIGN KEY (`announcement_id`) REFERENCES `announcement` (`id`),
  CONSTRAINT `fk_announce_with_services_services_and_prices1` FOREIGN KEY (`services_and_prices_id`) REFERENCES `services_and_prices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announce_with_services`
--

LOCK TABLES `announce_with_services` WRITE;
/*!40000 ALTER TABLE `announce_with_services` DISABLE KEYS */;
INSERT INTO `announce_with_services` VALUES (1,'2021-03-14 15:30:27','2021-03-15 15:30:27','2021-03-14 15:30:27',NULL,1,1),(2,'2021-03-14 21:31:43',NULL,'2021-03-14 21:31:43',NULL,1,2),(3,'2021-03-14 21:39:09','2021-03-15 21:39:09','2021-03-14 21:39:09',NULL,1,3),(4,'2021-03-14 15:30:27',NULL,'2021-03-14 15:30:27',NULL,1,7),(5,'2021-03-14 15:30:27',NULL,'2021-03-14 15:30:27',NULL,1,8),(6,'2021-03-14 21:34:18',NULL,'2021-03-14 21:34:18',NULL,2,2),(7,'2021-03-14 15:30:27','2021-03-15 15:30:27','2021-03-14 15:30:27',NULL,2,3),(8,'2021-03-14 15:30:27','2021-03-15 15:30:27','2021-03-14 15:30:27',NULL,3,5),(9,'2021-03-14 15:30:27','2021-03-15 15:30:27','2021-03-14 15:30:27',NULL,4,1),(10,'2021-03-14 15:30:27','2021-03-15 15:30:27','2021-03-14 15:30:27',NULL,5,3),(11,'2021-03-14 15:30:27','2021-03-21 15:30:27','2021-03-14 15:30:27',NULL,6,4),(12,'2021-03-14 15:30:27','2021-03-15 15:30:27','2021-03-14 15:30:27',NULL,7,5),(13,'2021-03-14 21:39:44','2021-03-21 21:39:44','2021-03-14 21:39:44',NULL,8,2),(14,'2021-03-14 15:30:27','2021-03-21 15:30:27','2021-03-14 15:30:27',NULL,8,6),(15,'2021-03-14 15:30:27','2021-03-21 15:30:27','2021-03-14 15:30:27',NULL,10,4),(16,'2021-03-14 21:45:23','2021-03-21 21:45:23','2021-03-14 21:45:23',NULL,8,2);
/*!40000 ALTER TABLE `announce_with_services` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `announce_with_services_BEFORE_INSERT` BEFORE INSERT ON `announce_with_services` FOR EACH ROW BEGIN
	DECLARE `days_period` tinyint;
    SET `days_period` = (SELECT `period_days` FROM `services_and_prices` where `services_and_prices`.`id` = NEW.`services_and_prices_id`);
    SET NEW.`stop_date` = IF (`days_period` != 0, date_add(NOW(),INTERVAL `days_period` DAY), NULL);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `announce_with_services_BEFORE_UPDATE` BEFORE UPDATE ON `announce_with_services` FOR EACH ROW BEGIN
	DECLARE `days_period` tinyint;
    SET `days_period` = (SELECT `period_days` FROM `services_and_prices` where `services_and_prices`.`id` = NEW.`services_and_prices_id`);
    SET NEW.`stop_date` = IF (`days_period` != 0, date_add(NOW(),INTERVAL `days_period` DAY), NULL);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(145) COLLATE utf8mb4_general_ci NOT NULL,
  `desc` varchar(245) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone_show_status` smallint NOT NULL DEFAULT '1' COMMENT '0-не показывать\n1-показать',
  `price` bigint NOT NULL,
  `address` varchar(245) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `sections_id` int unsigned NOT NULL,
  `announces_status_id` int unsigned NOT NULL,
  `cities_id` int unsigned NOT NULL,
  `users_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_announcement_sections1_idx` (`sections_id`),
  KEY `fk_announcement_announces_status1_idx` (`announces_status_id`),
  KEY `fk_announcement_cities1_idx` (`cities_id`),
  KEY `fk_announcement_users1_idx` (`users_id`),
  CONSTRAINT `fk_announcement_announces_status1` FOREIGN KEY (`announces_status_id`) REFERENCES `announces_status` (`id`),
  CONSTRAINT `fk_announcement_cities1` FOREIGN KEY (`cities_id`) REFERENCES `cities` (`id`),
  CONSTRAINT `fk_announcement_sections1` FOREIGN KEY (`sections_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `fk_announcement_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
INSERT INTO `announcement` VALUES (1,'Продается квартира','3-комнатная квартира в центре города, с ремонтом',1,5000000,'ул. Улица 1 234 строение 3','2021-03-14 14:36:13',NULL,1,1,4,11),(2,'Продается квартира','1-комнатная квартира, с ремонтом',1,2600000,'ул. Улица 2 1 строение 32','2021-03-14 14:36:13',NULL,1,1,1,12),(3,'Новый ПК','В отличном сосстоянии, 16 гб ОЗУ, CPU i7-7700, GTX 1060 6 GB',0,60000,'Центральный проспект, 134','2021-03-14 14:36:13',NULL,10,1,2,13),(4,'Видеокарта','Продам видеокарту RTX 3090',0,1000000,'ул. Советская 13','2021-03-14 14:36:13',NULL,10,1,3,14),(5,'Продам диван',NULL,1,3500,'ул. Улица 1 234 строение 3','2021-03-14 14:36:13','2021-03-14 14:52:18',6,1,7,15),(6,'Продам стол кухонный','стол складной',0,2000,'проспект Победы 18','2021-03-14 14:36:13',NULL,6,1,2,16),(7,'Продам демисезонное пальто женское','Размер L, цвет серый, носила пару раз',1,13000,'ул. Гвардейцев 156, подъезд 4','2021-03-14 14:36:13',NULL,8,1,1,17),(8,'Продается мужской пиджак','Размер XXL, торг',0,3500,NULL,'2021-03-14 14:36:13',NULL,8,1,9,18),(9,'Продам диск для PS5',NULL,1,5000,'ул. Центральная 133','2021-03-14 14:36:13',NULL,11,1,10,19),(10,'Продается приставка игровая XBOX 360','Полный комплект',0,10000,NULL,'2021-03-14 14:36:13',NULL,11,1,5,20),(11,'Гараж','Под Газель',0,250000,NULL,'2021-03-14 14:36:13',NULL,2,4,8,21),(12,'Стиральная машинка',NULL,0,8000,NULL,'2021-03-14 14:36:13',NULL,5,2,6,11),(13,'Теплица','теплица 1,5 метра на 4 метра',0,1000,NULL,'2021-03-14 14:36:13',NULL,9,3,3,12),(14,'Кашачий домик',NULL,0,2000,NULL,'2021-03-14 14:36:13',NULL,7,2,7,12),(15,'Продаются ботинки','Размер 43, кожа',0,5000,NULL,'2021-03-14 14:38:16',NULL,8,3,2,15),(16,'Ошейник для кошки',NULL,0,250,NULL,'2021-03-15 12:18:38',NULL,7,1,3,13),(17,'Поводок для собаки','в отличном состоянии',0,500,'пр. 8 марта 111','2021-03-15 12:20:28',NULL,7,1,4,12);
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `announcement_BEFORE_INSERT` BEFORE INSERT ON `announcement` FOR EACH ROW BEGIN
	if isnull(NEW.`desc`)+isnull(NEW.`address`) != 0 then
		signal sqlstate '45000'
        set message_text = 'Поле desc и address не должно быть NULL!';
    end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `announcement_BEFORE_UPDATE` BEFORE UPDATE ON `announcement` FOR EACH ROW BEGIN
	if isnull(NEW.`desc`)+isnull(NEW.`address`) != 0 then
		signal sqlstate '45000'
        set message_text = 'Поле desc и address не должно быть NULL!';
    end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `announces_cnt_by_city`
--

DROP TABLE IF EXISTS `announces_cnt_by_city`;
/*!50001 DROP VIEW IF EXISTS `announces_cnt_by_city`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `announces_cnt_by_city` AS SELECT 
 1 AS `announce_cnt`,
 1 AS `announces`,
 1 AS `city`,
 1 AS `users`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `announces_cnt_by_user`
--

DROP TABLE IF EXISTS `announces_cnt_by_user`;
/*!50001 DROP VIEW IF EXISTS `announces_cnt_by_user`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `announces_cnt_by_user` AS SELECT 
 1 AS `announce_count`,
 1 AS `announces`,
 1 AS `user_name`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `announces_status`
--

DROP TABLE IF EXISTS `announces_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announces_status` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announces_status`
--

LOCK TABLES `announces_status` WRITE;
/*!40000 ALTER TABLE `announces_status` DISABLE KEYS */;
INSERT INTO `announces_status` VALUES (1,'Активно','2021-03-09 22:32:22',NULL),(2,'Снято с публикации','2021-03-09 22:32:22',NULL),(3,'Зарезервировано','2021-03-09 22:32:22',NULL),(4,'Закрыто','2021-03-09 22:32:22','2021-03-14 12:52:19');
/*!40000 ALTER TABLE `announces_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'Москва','2021-03-09 20:53:05',NULL),(2,'Оренбург','2021-03-09 20:53:05',NULL),(3,'Ростов','2021-03-09 20:53:05',NULL),(4,'Санкт-Петербург','2021-03-09 20:53:05',NULL),(5,'Сызрань','2021-03-09 20:53:05',NULL),(6,'Екатеринбург','2021-03-09 20:53:05',NULL),(7,'Самара','2021-03-09 20:53:05',NULL),(8,'Волгоград','2021-03-09 20:53:05',NULL),(9,'Калининград','2021-03-09 20:53:05',NULL),(10,'Тверь','2021-03-09 20:53:05',NULL),(19,'Ижевск','2021-03-15 13:02:50',NULL);
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `city_announces_cnt_over2`
--

DROP TABLE IF EXISTS `city_announces_cnt_over2`;
/*!50001 DROP VIEW IF EXISTS `city_announces_cnt_over2`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `city_announces_cnt_over2` AS SELECT 
 1 AS `city`,
 1 AS `announces`,
 1 AS `price`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `from` varchar(245) COLLATE utf8mb4_general_ci NOT NULL,
  `to` varchar(245) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `announcement_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_delivery_announcement1_idx` (`announcement_id`),
  CONSTRAINT `fk_delivery_announcement1` FOREIGN KEY (`announcement_id`) REFERENCES `announcement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES (1,'Москва','Санкт-Петербург','2021-03-14 20:24:48',NULL,'2021-03-16 00:00:00',7),(2,'Калининград','Самара','2021-03-14 20:24:48',NULL,'2021-04-16 00:00:00',8),(3,'Оренбург','Ростов','2021-03-14 20:24:48',NULL,'2021-03-26 00:00:00',3),(4,'Оренбург','Самара','2021-03-14 20:24:48',NULL,'2021-03-23 00:00:00',15),(5,'Ростов','Екатеринбург','2021-03-14 20:24:48',NULL,'2021-03-20 00:00:00',4),(6,'Тверь','Москва','2021-03-14 20:24:48',NULL,'2021-04-10 00:00:00',9);
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(245) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'media1','2021-03-09 22:10:08',NULL),(2,'media2','2021-03-09 22:10:08',NULL),(3,'media3','2021-03-09 22:10:08',NULL),(4,'media4','2021-03-09 22:10:08',NULL),(5,'media5','2021-03-09 22:10:08',NULL),(6,'media6','2021-03-09 22:10:08',NULL),(7,'media7','2021-03-09 22:10:08',NULL),(8,'media8','2021-03-09 22:10:08',NULL),(9,'media9','2021-03-09 22:10:08',NULL),(10,'media10','2021-03-09 22:10:08',NULL),(11,'media11','2021-03-09 22:19:58',NULL),(12,'media12','2021-03-09 22:19:58',NULL),(13,'media13','2021-03-09 22:19:58',NULL),(14,'media14','2021-03-09 22:19:58',NULL),(15,'media15','2021-03-09 22:19:58',NULL),(16,'media16','2021-03-09 22:19:58',NULL),(17,'media17','2021-03-09 22:19:58',NULL),(18,'media18','2021-03-09 22:19:58',NULL),(19,'media19','2021-03-09 22:19:58',NULL),(20,'media20','2021-03-09 22:19:58',NULL);
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profiles` (
  `users_id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(145) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(145) COLLATE utf8mb4_general_ci NOT NULL,
  `gender` smallint DEFAULT NULL COMMENT '0-man\n1-woman',
  `birthday` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `cities_id` int unsigned NOT NULL,
  `media_id` int unsigned NOT NULL,
  PRIMARY KEY (`users_id`),
  KEY `fk_profiles_cities1_idx` (`cities_id`),
  KEY `fk_profiles_media1_idx` (`media_id`),
  CONSTRAINT `fk_profiles_cities1` FOREIGN KEY (`cities_id`) REFERENCES `cities` (`id`),
  CONSTRAINT `fk_profiles_media1` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`),
  CONSTRAINT `fk_profiles_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` VALUES (11,'Иванов','Иван',0,'1976-12-02','2021-03-09 22:13:51',NULL,1,1),(12,'Петров','Петр',0,'1972-10-13','2021-03-09 22:16:45',NULL,2,2),(13,'Сидорова','Мария',1,'1983-01-01','2021-03-09 22:16:45','2021-03-09 22:29:12',3,3),(14,'Алексеев','Владимир',0,'1991-03-02','2021-03-09 22:16:45',NULL,4,4),(15,'Антонова','Нина',1,'1998-11-04','2021-03-09 22:16:45','2021-03-09 22:29:12',8,5),(16,'Владимиров','Александр',0,'1977-12-23','2021-03-09 22:16:45','2021-03-09 22:26:14',6,6),(17,'Александрова','Надежда',1,'2001-12-02','2021-03-09 22:16:45','2021-03-09 22:29:12',6,7),(18,'Иванова','Ольга',1,'1963-05-12','2021-03-09 22:16:45','2021-03-09 22:29:12',7,8),(19,'Пушкарева','Светлана',1,'2006-12-11','2021-03-09 22:16:45','2021-03-09 22:29:12',10,9),(20,'Светиков','Михаил',0,'2005-06-16','2021-03-09 22:16:45',NULL,9,10),(21,'Андронова','Елена',1,'2005-06-16','2021-03-09 22:27:59','2021-03-09 22:29:12',5,7);
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(145) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'Квартиры','2021-03-09 22:40:50',NULL),(2,'Гаражи','2021-03-09 22:40:50',NULL),(3,'Дома','2021-03-09 22:40:50',NULL),(4,'Автомобили','2021-03-09 22:40:50',NULL),(5,'Бытавая техника','2021-03-09 22:40:50',NULL),(6,'Мебель','2021-03-09 22:40:50',NULL),(7,'Товары для животных','2021-03-09 22:40:50',NULL),(8,'Одежда и обувь','2021-03-09 22:40:50',NULL),(9,'Для дома и дачи','2021-03-09 22:40:50',NULL),(10,'Компьютерная техника','2021-03-09 22:40:50',NULL),(11,'Видеоигры','2021-03-09 22:40:50',NULL);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services_and_prices`
--

DROP TABLE IF EXISTS `services_and_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services_and_prices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `price` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `period_days` tinyint DEFAULT NULL COMMENT 'Срок действие услуги в днях\n0- бессрочно',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services_and_prices`
--

LOCK TABLES `services_and_prices` WRITE;
/*!40000 ALTER TABLE `services_and_prices` DISABLE KEYS */;
INSERT INTO `services_and_prices` VALUES (1,'До 10 раз больше просмотров на 1 день',280,'2021-03-14 13:21:26',NULL,1),(2,'До 10 раз больше просмотров на 7 дней',950,'2021-03-14 13:21:26',NULL,7),(3,'До 5 раз больше просмотров на 1 день',160,'2021-03-14 13:21:26',NULL,1),(4,'До 5 раз больше просмотров на 7 день',560,'2021-03-14 13:21:26',NULL,7),(5,'До 2 раз больше просмотров на 1 день',80,'2021-03-14 13:21:26',NULL,1),(6,'До 2 раз больше просмотров на 7 день',280,'2021-03-14 13:21:26',NULL,7),(7,'Сделать XL-объявлением',120,'2021-03-14 13:21:26',NULL,0),(8,'Выделить объявление цветом',120,'2021-03-14 13:21:26',NULL,0);
/*!40000 ALTER TABLE `services_and_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(145) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` bigint NOT NULL,
  `password_hash` varchar(65) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_UNIQUE` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (11,'1@mail.ru',71234567891,'dc3c2c385c3ba766bfb3248250f6636fe90bdd31'),(12,'2@mail.ru',71234567892,'2dd32d1e318274f5046d62ed8588e3dba7451b13'),(13,'3@mail.ru',71234567893,'f620bb81786c71a3d65e5eaa72faf7032aa1b8ed'),(14,'4@mail.ru',71234567894,'0096ef0563dcd5127a9664499c23e607da892059'),(15,'5@mail.ru',71234567895,'1cfd5d5229d6f1df5f753c5b7c20574a05c7160f'),(16,'6@mail.ru',71234567896,'20048cdaa2e839b411b92e166c077ff7b9c72428'),(17,'7@mail.ru',71234567897,'add6229bc8f3e126a37ea5eb4e81419b45c0c753'),(18,'8@mail.ru',71234567898,'b6ba4ac95ed010852f5e9313ae72fe466734385b'),(19,'9@mail.ru',71234567899,'ae02ab53b8dc68d061bbd029894cf0425c810e9e'),(20,'10@mail.ru',71234567890,'ba17512d742cd119fff2d5a6bce2cd9344ca7502'),(21,'11@mail.ru',71234567881,'871a914b19471f7b678c500d6bea70062d3cbcb0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'avito'
--

--
-- Dumping routines for database 'avito'
--
/*!50003 DROP PROCEDURE IF EXISTS `insert_and_return_cities` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_and_return_cities`(IN city_name varchar(100), OUT city_id int)
BEGIN
	INSERT 
		`cities` (`name`)
    VALUES
		(city_name);
	
    SET city_id = (SELECT id FROM cities WHERE id = last_insert_id());
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `announces_cnt_by_city`
--

/*!50001 DROP VIEW IF EXISTS `announces_cnt_by_city`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `announces_cnt_by_city` AS select count(`a`.`cities_id`) AS `announce_cnt`,group_concat(`a`.`id` separator ',') AS `announces`,`c`.`name` AS `city`,group_concat(concat(`p`.`first_name`,' ',`p`.`last_name`) separator ',') AS `users` from ((`announcement` `a` join `cities` `c` on((`c`.`id` = `a`.`cities_id`))) join `profiles` `p` on((`p`.`users_id` = `a`.`users_id`))) group by `city` order by `announce_cnt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `announces_cnt_by_user`
--

/*!50001 DROP VIEW IF EXISTS `announces_cnt_by_user`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `announces_cnt_by_user` AS select count(`a`.`id`) AS `announce_count`,group_concat(`a`.`id` separator ',') AS `announces`,concat(`p`.`first_name`,' ',`p`.`last_name`) AS `user_name`,`c`.`name` AS `name` from ((`announcement` `a` join `cities` `c` on((`c`.`id` = `a`.`cities_id`))) join `profiles` `p` on((`p`.`users_id` = `a`.`users_id`))) group by `user_name` order by `announce_count` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `city_announces_cnt_over2`
--

/*!50001 DROP VIEW IF EXISTS `city_announces_cnt_over2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `city_announces_cnt_over2` AS select `c`.`name` AS `city`,group_concat(`a`.`id` separator ',') AS `announces`,group_concat(`a`.`price` separator ',') AS `price` from (`cities` `c` join `announcement` `a` on((`c`.`id` = `a`.`cities_id`))) where (`a`.`price` > 3000) group by `city` having (count(`a`.`id`) >= 2) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-15 13:04:24

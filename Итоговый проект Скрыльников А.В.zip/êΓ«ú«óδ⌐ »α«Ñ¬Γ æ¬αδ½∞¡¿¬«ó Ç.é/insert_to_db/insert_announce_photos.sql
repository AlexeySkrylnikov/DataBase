INSERT `announce_photos`
(`announcement_id`,`media_id`)
VALUES
(1,15),
(2,3),
(14,11),
(4,6),
(3,5),
(8,7),
(7,8),
(15,13),
(12,20),
(5,10),
(5,9),
(7,2);
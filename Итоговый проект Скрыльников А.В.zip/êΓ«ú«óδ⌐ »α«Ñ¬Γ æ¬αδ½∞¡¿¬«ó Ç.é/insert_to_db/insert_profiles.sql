INSERT `profiles` (`users_id`,`first_name`,`last_name`,`gender`,`birthday`,`cities_id`,`media_id`)
VALUES
(12,'first_name2','last_name2',0,'1972-10-13',2,2),
(13,'first_name3','last_name3',0,'1983-01-01',3,3),
(14,'first_name4','last_name4',0,'1991-03-02',4,4),
(15,'first_name5','last_name5',0,'1998-11-04',8,5),
(16,'first_name6','last_name6',0,'1977-12-23',5,6),
(17,'first_name7','last_name7',0,'2001-12-02',6,7),
(18,'first_name8','last_name8',0,'1963-05-12',7,8),
(19,'first_name9','last_name9',0,'2016-12-11',10,9),
(20,'first_name10','last_name10',0,'2005-06-16',9,10);
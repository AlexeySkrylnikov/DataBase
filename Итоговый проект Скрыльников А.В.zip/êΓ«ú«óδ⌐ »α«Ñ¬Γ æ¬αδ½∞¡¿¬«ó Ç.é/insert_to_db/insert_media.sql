INSERT `media` (`file_name`)
VALUES
('media11'),
('media12'),
('media13'),
('media14'),
('media15'),
('media16'),
('media17'),
('media18'),
('media19'),
('media20');
INSERT `users` (`email`,`phone`,`password_hash`)
VALUES 
('1@mail.ru',71234567891,SHA1(`email`)),
('2@mail.ru',71234567892,SHA1(`email`)),
('3@mail.ru',71234567893,SHA1(`email`)),
('4@mail.ru',71234567894,SHA1(`email`)),
('5@mail.ru',71234567895,SHA1(`email`)),
('6@mail.ru',71234567896,SHA1(`email`)),
('7@mail.ru',71234567897,SHA1(`email`)),
('8@mail.ru',71234567898,SHA1(`email`)),
('9@mail.ru',71234567899,SHA1(`email`)),
('10@mail.ru',71234567890,SHA1(`email`));
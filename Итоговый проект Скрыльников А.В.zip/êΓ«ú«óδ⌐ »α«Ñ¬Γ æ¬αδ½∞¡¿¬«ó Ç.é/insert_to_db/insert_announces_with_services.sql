INSERT `announce_with_services`
(`announcement_id`,`services_and_prices_id`)
VALUES
(1,1),
(1,7),
(1,8),
(2,3),
(3,5),
(4,1),
(5,3),
(6,4),
(7,5),
(8,6),
(10,4);
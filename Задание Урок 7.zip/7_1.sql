SELECT 
	group_concat(`o`.`number`) as `order_number`,
    `o`.`user_id` as `order_user_id`,
    `o`.`created_at` as `order_created`,
    `u`.`id` as `user_id`,
    concat(`u`.`first_name`,' ',`u`.`last_name`) as `user_name`
FROM 
	`orders` `o`
JOIN
	`users` `u` on `u`.`id`=`o`.`user_id`
GROUP BY 
	`u`.`id`
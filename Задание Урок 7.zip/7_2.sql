SELECT 
	`c`.`name` as `category_name`,
	group_concat(`p`.`name`) as `product_name`,
	`p`.`price`
FROM
	`catalogs` `c`
LEFT JOIN
	`products` `p`
ON 
	`c`.`id` = `p`.`category_id`
 GROUP BY
	`c`.`id`


SELECT
	`cities_from`.`name` as `from`,
	`cities_to`.`name` as `to`,
	`f`.`departure_time`,
	`f`.`arrive_time`
FROM
	`flights` `f`
JOIN
	`cities` `cities_from`
ON 
	`f`.`from` = `cities_from`.`label`
JOIN
	`cities` `cities_to`
ON 
	`f`.`to` = `cities_to`.`label`
ORDER BY
	`f`.`departure_time`
-- кто из пользователей больше всего написал сообщений пользователю с ид = 99
select 
	`from_users_id`,
    (SELECT concat(`firstname`,' ', `lastname`) from `profiles` where `users_id` = `from_users_id`) as `from_user_name`,
	`to_users_id`,
    (SELECT concat(`firstname`,' ', `lastname`) from `profiles` where `users_id` = `to_users_id`) as `to_user_name`,
	count(*) as `messages_cnt`
from 
	`messages`
 where 
	 `to_users_id` = 99
group by 
	`from_users_id`
order by 
	`messages_cnt` DESC
limit 1
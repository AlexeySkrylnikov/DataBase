-- количество поставленных лайков (медиа, постам и сообщениям)
-- десятью самыми молодыми пользователями
select 
	`firstname`,`lastname`,
	`users_id`,
	timestampdiff(YEAR,`birthday`,NOW()) as `age`,
	(select count(*) from `likes` where `users_id` = `profiles`.`users_id`) as `likes_cnt`
from 
	`profiles`
where 
	timestampdiff(YEAR,`birthday`,NOW())<=17
order by 
	`age`,`likes_cnt`
limit 
	10
-- кто поставил больше всего лайков, мужчины или женщины?
SELECT 
	count(*) as `cnt_likes`,
	(select 
		IF (`gender`='m','мужчины','женщины') 
	 from 
     `profiles` 
     where 
		`users_id` = `likes`.`users_id`
	 and 
		`profiles`.`gender`
	 in 
		('m','f')) 
	 as 
		`gender`
FROM 
	`likes`
group by 
	`gender`
order by
	`cnt_likes` DESC
limit 1
-- найти пользователей которые проявляют наименьшую активность
-- посчитаем кол-во лайков, постов, загруженных медиа и сообщений в соцсети
-- те у кого кол-во меньше всего (например <5), тот и менее активен
select 
	(select concat(`firstname`,' ',`lastname`) from `profiles` where `users_id`=`users`.`id`) as `username` -- ,
    /*(select count(*) from `messages` where `from_users_id`=`users`.`id`)+
	(select count(*) from `messages` where `to_users_id`=`users`.`id`)+
	(select count(*) from `likes` where `users_id`=`users`.`id`)+
    (select count(*) from `media` where `users_id`=`users`.`id`)+
	(select count(*) from `posts` where `users_id`=`users`.`id`) as `total`*/
from
	users
where
    (select count(*) from `messages` where `from_users_id`=`users`.`id`)+
	(select count(*) from `messages` where `to_users_id`=`users`.`id`)+
	(select count(*) from `likes` where `users_id`=`users`.`id`)+
    (select count(*) from `media` where `users_id`=`users`.`id`)+
	(select count(*) from `posts` where `users_id`=`users`.`id`) <5
-- order by `total`
order by
	(select concat(`firstname`,' ',`lastname`) from `profiles` where `users_id`=`users`.`id`) 
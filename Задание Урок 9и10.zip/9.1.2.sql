-- Создайте представление, которое выводит название name товарной позиции из таблицы products 
-- и соответствующее название каталога name из таблицы catalogs.

CREATE 
VIEW `show_names` AS
    SELECT 
        `p`.`name` AS `product_name`, `c`.`name` AS `catalogs_name`
    FROM
		`products` `p`
	JOIN `catalogs` `c` ON `p`.`category_id` = `c`.`id`
    ORDER BY `p`.`name`
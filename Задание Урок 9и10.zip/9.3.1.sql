-- Создайте хранимую функцию hello(), которая будет возвращать приветствие, 
-- в зависимости от текущего времени суток. С 6:00 до 12:00 функция должна возвращать 
-- фразу "Доброе утро", с 12:00 до 18:00 функция должна возвращать фразу "Добрый день", 
-- с 18:00 до 00:00 — "Добрый вечер", с 00:00 до 6:00 — "Доброй ночи".

-- создаем процедуру
USE `shop`;
DROP procedure IF EXISTS `say_hello`;

USE `shop`;
DROP procedure IF EXISTS `shop`.`say_hello`;
;

DELIMITER $$
USE `shop`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `say_hello`(IN t datetime, OUT say VARCHAR(25))
BEGIN
    
    SET @current_hour = TIME(t);  
    IF @current_hour between '06:00:00' and '11:59:59' THEN
		SET say = 'Доброе утро!';
	ElSEIF @current_hour between '12:00:00' and '17:59:59' THEN
    	SET say = 'Добрый день!';
	ELSEIF @current_hour between '18:00:00' and '23:59:59' THEN
    	SET say = 'Добрый вечер!';
	ELSEIF @current_hour between '00:00:00' and '05:59:59' THEN
    	SET say = 'Доброй ночи!';
	end if;
    
    SET say=CONCAT(@current_hour,' - ',say);
END$$

DELIMITER ;
;

-- вызываем процедуру
call say_hello(NOW(),@say);

select @say
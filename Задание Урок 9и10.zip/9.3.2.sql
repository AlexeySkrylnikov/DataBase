CREATE DEFINER=`root`@`localhost` TRIGGER `products_BEFORE_INSERT` BEFORE INSERT ON `products` FOR EACH ROW BEGIN
	if isnull(NEW.`name`)+isnull(NEW.`desc`) = 2 then
		signal sqlstate '45000'
        set message_text = 'Поле NAME или поле DESC должны иметь определенное значение!';
    end if;
END
SELECT round(exp(sum(ln(`value`)))) as `result` from `catalogs`;

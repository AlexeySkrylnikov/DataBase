-- количество дней рождений выпадающих на каждый день недели с сортировкой по дням недели
SELECT 
	count(*) as `count_birthday`,
	dayname(concat_ws('-',YEAR(NOW()),MONTH(`birthday`),DAY(`birthday`))) as `day_name`
FROM 
	`profiles`
group by 
	`day_name`
order by 
	case `day_name`
		when 'monday' then 0
		when 'tuesday' then 1
		when 'wednesday' then 3
		when 'thursday' then 4
		when 'friday' then 5
		when 'saturday' then 6
		else 7
	end;
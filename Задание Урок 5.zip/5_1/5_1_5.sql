SELECT * FROM vk_new.catalogs
where id in (5,1,2)
order by 
case id
when 5 then 0
when 1 then 1
when 2 then 2
end;
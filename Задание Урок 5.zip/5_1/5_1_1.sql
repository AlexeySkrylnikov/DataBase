update `profiles` set
updated_at = NOW()
where updated_at is null;

select * from `profiles`
order by updated_at desc
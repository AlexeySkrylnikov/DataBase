SELECT 
*
FROM `storehouses_products`
order by `value`=0, `value`
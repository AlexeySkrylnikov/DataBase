SELECT 
users_id,firstname,lastname,birthday,
monthname(birthday) as birt_month
FROM vk_new.profiles
where monthname(birthday) = 'may' or monthname(birthday) = 'august'
order by birt_month,birthday
